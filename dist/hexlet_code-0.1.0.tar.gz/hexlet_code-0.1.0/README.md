### Hexlet tests and linter status:
[![Actions Status](https://github.com/AnnAnouk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AnnAnouk/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/80a8b174b619c6bbb3aa/maintainability)](https://codeclimate.com/github/AnnAnouk/python-project-49/maintainability)